package com.main.beans.inner;

public class CloudsBean {
	private int all;

	public int getAll() {
		return all;
	}

	public void setAll(int all) {
		this.all = all;
	}
	
}
