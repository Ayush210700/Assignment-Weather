package com.main.config;

public class AppConfig {
	public static final String API_URL="https://samples.openweathermap.org/data/2.5/forecast/hourly?q=London,us&appid=b6907d289e10d714a6e88b30761fae22";
}
