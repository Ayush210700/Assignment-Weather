# mvn clean
# mvn package
docker build -t "assignment-project-0.0.1" .