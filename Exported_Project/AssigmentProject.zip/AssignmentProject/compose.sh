# docker-compose up
docker run -it assignment-project-0.0.1